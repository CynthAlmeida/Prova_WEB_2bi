﻿using Cadastrocliente.Models;
using Microsoft.EntityFrameworkCore;

namespace Cadastrocliente.Data
{
    public class AppCont : DbContext
    {
        public AppCont(DbContextOptions<AppCont> options) : base(options)
        {

        }

        public DbSet<Cliente> Alunos { get; set; }
    }
}
