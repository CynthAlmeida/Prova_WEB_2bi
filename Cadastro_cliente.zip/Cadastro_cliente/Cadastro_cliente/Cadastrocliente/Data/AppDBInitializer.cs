﻿using Cadastrocliente.Models;

namespace Cadastrocliente.Data
{
    public class AppDBInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppCont>();
                context.Database.EnsureCreated();

                if (!context.Alunos.Any())
                {
                    context.Alunos.AddRange(new List<Cliente>()
                    {
                        new Cliente()
                        {
                            Name = "Cynthia Almeida",
                            Email = "cynthiaalmeida@gmail.com",
                            Rua = "Siria",
                            Numero = 210,
                            Cidade = "Ribeirao Preto",
                            Estado = "São Paulo",
                            Pais = "Brasil"

                        },
                        new Cliente()
                        {

                            Name = "Cybelle Santos",
                            Email = "cyborg@hotmail.com",
                            Rua = "São Paulo",
                            Numero = 345,
                            Cidade = "Ribeirao Preto",
                            Estado = "São Paulo",
                            Pais = "Brasil"
                        },
                        new Cliente()
                        {

                            Name = "Osvaldo Pereira",
                            Email = "pereira.osvaldo@gmail.com",
                            Rua = "Av. Portugal",
                            Numero = 1256,
                            Cidade = "Ribeirao Preto",
                            Estado = "São Paulo",
                            Pais = "Brasil"
                        },
                        new Cliente()
                        {

                            Name = "Maria José",
                            Email = "maria.jose@gmail.com",
                            Rua = "Marisa",
                            Numero = 78,
                            Cidade = "Ribeirao Preto",
                            Estado = "São Paulo",
                            Pais = "Brasil"
                        },
                        new Cliente()
                        {

                            Name = "Marcia de Castro",
                            Email = "marcinha@hotmail.com",
                            Rua = "Marisa",
                            Numero = 78,
                            Cidade = "Ribeirao Preto",
                            Estado = "São Paulo",
                            Pais = "Brasil"
                        }
                    });
                    context.SaveChanges();
                }
            }
        }
    }
}
