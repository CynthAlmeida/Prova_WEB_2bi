﻿using Microsoft.AspNetCore.Mvc;
using Cadastrocliente.Data;

namespace Cadastrocliente.Controllers
{
    public class ClienteController : Controller
    {
        private readonly AppCont _appCont;

        
        public ClienteController(AppCont appCont) 
         {
           _appCont = appCont;

          }

        public IActionResult Index()
        {
            var allTasks = _appCont.Alunos.ToList();
            return View(allTasks);
        }
    }
}
